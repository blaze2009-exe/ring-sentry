#pragma once

#ifndef RING_SENTRY_H
#define RING_SENTRY_H

#include <ntdef.h>

#define RING_SENTRY_DEVICE_NAME     L"\\Device\\RingSentry"
#define RING_SENTRY_DOS_DEVICE_NAME L"\\DosDevices\\RingSentry"

#define IOCTL_RING_SENTRY_AUDIT_ALL \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x900, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_RING_SENTRY_AUDIT_RING0 \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x901, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_RING_SENTRY_AUDIT_RING_MINUS1 \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x902, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_RING_SENTRY_AUDIT_RING_MINUS2 \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x903, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_RING_SENTRY_AUDIT_RING_MINUS3 \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x904, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define STATUS_INTEGRITY_VIOLATION   ((NTSTATUS)0xC0000001L)
#define STATUS_INTEGRITY_CLEAN       ((NTSTATUS)0x00000000L)

// Ring 0: Kernel Integrity Diagnostics
typedef struct _RING0_DIAGNOSTICS {
    BOOLEAN SsdtHookDetected;
    BOOLEAN IdtHookDetected;
    BOOLEAN DkomHiddenProcessDetected;
    BOOLEAN HardwareBreakpointPresent;
    BOOLEAN UnbackedExecutableMemoryPresent;
    BOOLEAN DseTampered;
    ULONG64 LstarTargetAddress;
    ULONG64 Cr3Expected;
    ULONG64 Cr3Actual;
    ULONG   ActiveProcessCountDiscrepancy;
} RING0_DIAGNOSTICS, *PRING0_DIAGNOSTICS;

// Ring -1: Hypervisor (VMX/SVM) Diagnostics
typedef struct _RING_MINUS1_DIAGNOSTICS {
    BOOLEAN HypervisorPresentCpuid;
    BOOLEAN HypervisorTimingAnomalyDetected;
    BOOLEAN EptShadowingDetected;
    BOOLEAN VmxLockedInMsr;
    BOOLEAN Cr4VmxeActive;
    ULONG64 AverageCpuidExitCycles;
    ULONG64 BaselineInstructionCycles;
    ULONG64 TimingRatio; // (ExitCycles / BaselineCycles) * 100
    CHAR    HypervisorSignature[13];
} RING_MINUS1_DIAGNOSTICS, *PRING_MINUS1_DIAGNOSTICS;

// Ring -2: SMM (System Management Mode) Diagnostics
typedef struct _RING_MINUS2_DIAGNOSTICS {
    BOOLEAN SmramLocked;          // D_LCK bit in SMRAMC
    BOOLEAN SmramOpen;            // D_OPEN bit
    BOOLEAN SmiAnomalyDetected;    // Unexpected SMI count spikes
    ULONG64 SmiCountInitial;
    ULONG64 SmiCountFinal;
    ULONG64 SmiDelta;
    ULONG64 TsegBaseAddress;
    ULONG64 TsegLimitAddress;
    ULONG64 SmiExecutionJitterCycles;
} RING_MINUS2_DIAGNOSTICS, *PRING_MINUS2_DIAGNOSTICS;

// Ring -3: Management Engine (CSME/PSP & TPM) Diagnostics
typedef struct _RING_MINUS3_DIAGNOSTICS {
    BOOLEAN HeciInterfacePresent;
    BOOLEAN MeManufacturingModeActive; // Security risk if active
    BOOLEAN MeStateClean;              // Current Working State == Normal (0x5)
    BOOLEAN TpmPresent;
    BOOLEAN TpmPcrIntegrityValid;
    BOOLEAN IommuDmarActive;
    ULONG   MeWorkingState;
    ULONG   MeFwStatusRaw;
    UCHAR   TpmPcr0Hash[32];           // SHA-256 measurement of BIOS/CRTM
    UCHAR   TpmPcr7Hash[32];           // SHA-256 measurement of Secure Boot
} RING_MINUS3_DIAGNOSTICS, *PRING_MINUS3_DIAGNOSTICS;

// Aggregate telemetry report across all rings
typedef struct _RING_SENTRY_REPORT {
    ULONG64 Timestamp;
    RING0_DIAGNOSTICS       Ring0;
    RING_MINUS1_DIAGNOSTICS RingMinus1;
    RING_MINUS2_DIAGNOSTICS RingMinus2;
    RING_MINUS3_DIAGNOSTICS RingMinus3;
    BOOLEAN OverallTamperDetected;
} RING_SENTRY_REPORT, *PRING_SENTRY_REPORT;

// Forward function prototypes
NTSTATUS AuditRing0Kernel(PRING0_DIAGNOSTICS Diag);
NTSTATUS AuditRingMinus1Hypervisor(PRING_MINUS1_DIAGNOSTICS Diag);
NTSTATUS AuditRingMinus2Smm(PRING_MINUS2_DIAGNOSTICS Diag);
NTSTATUS AuditRingMinus3Platform(PRING_MINUS3_DIAGNOSTICS Diag);

#endif // RING_SENTRY_H

