@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run_audit.ps1"

echo.
echo ================================================================================
echo Report written to: "%~dp0ring_sentry_report.txt"
echo Press any key to open the full report in Notepad...
echo ================================================================================
pause >nul
start notepad.exe "%~dp0ring_sentry_report.txt"
