# Ring Sentry Quick Launcher
param(
    [switch]$OpenReport
)

$PSScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$clientPath   = Join-Path $PSScriptRoot "client\RingSentryController.cs"
$reportPath   = Join-Path $PSScriptRoot "ring_sentry_report.txt"
$jsonPath     = Join-Path $PSScriptRoot "ring_sentry_report.json"

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "                   STARTING RING SENTRY SILICON SCAN                            " -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan

Add-Type -Path $clientPath -ReferencedAssemblies "System.Management.dll"

# Run main and pipe directly to console and disk report
& {
    [RingSentry.Program]::Main(@($PSScriptRoot))
} | Tee-Object -FilePath $reportPath

Write-Host "`n[+] Report successfully saved to disk:" -ForegroundColor Green
Write-Host "    --> $reportPath" -ForegroundColor Yellow

if (Test-Path $jsonPath) {
    Write-Host "    --> $jsonPath" -ForegroundColor Yellow
}

if ($OpenReport) {
    Start-Process notepad.exe $reportPath
}
