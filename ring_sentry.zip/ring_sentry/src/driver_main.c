#include <ntddk.h>
#include "../include/ring_sentry.h"

DRIVER_INITIALIZE DriverEntry;
DRIVER_UNLOAD     DriverUnload;
__drv_dispatchType(IRP_MJ_CREATE)         DRIVER_DISPATCH RingSentryCreate;
__drv_dispatchType(IRP_MJ_CLOSE)          DRIVER_DISPATCH RingSentryClose;
__drv_dispatchType(IRP_MJ_DEVICE_CONTROL) DRIVER_DISPATCH RingSentryDeviceControl;

PDEVICE_OBJECT g_DeviceObject = NULL;

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);

    UNICODE_STRING devName, symLink;
    RtlInitUnicodeString(&devName, RING_SENTRY_DEVICE_NAME);
    RtlInitUnicodeString(&symLink, RING_SENTRY_DOS_DEVICE_NAME);

    NTSTATUS status = IoCreateDevice(
        DriverObject,
        0,
        &devName,
        FILE_DEVICE_UNKNOWN,
        FILE_DEVICE_SECURE_OPEN,
        FALSE,
        &g_DeviceObject
    );

    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = IoCreateSymbolicLink(&symLink, &devName);
    if (!NT_SUCCESS(status)) {
        IoDeleteDevice(g_DeviceObject);
        return status;
    }

    DriverObject->MajorFunction[IRP_MJ_CREATE] = RingSentryCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = RingSentryClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = RingSentryDeviceControl;
    DriverObject->DriverUnload = DriverUnload;

    return STATUS_SUCCESS;
}

VOID DriverUnload(PDRIVER_OBJECT DriverObject) {
    UNICODE_STRING symLink;
    RtlInitUnicodeString(&symLink, RING_SENTRY_DOS_DEVICE_NAME);
    IoDeleteSymbolicLink(&symLink);

    if (DriverObject->DeviceObject) {
        IoDeleteDevice(DriverObject->DeviceObject);
    }
}

NTSTATUS RingSentryCreate(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

NTSTATUS RingSentryClose(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

NTSTATUS RingSentryDeviceControl(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    UNREFERENCED_PARAMETER(DeviceObject);
    PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
    ULONG controlCode = stack->Parameters.DeviceIoControl.IoControlCode;
    ULONG outLen = stack->Parameters.DeviceIoControl.OutputBufferLength;
    PVOID buffer = Irp->AssociatedIrp.SystemBuffer;

    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    ULONG_PTR bytesReturned = 0;

    switch (controlCode) {
        case IOCTL_RING_SENTRY_AUDIT_ALL: {
            if (outLen < sizeof(RING_SENTRY_REPORT) || !buffer) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }

            PRING_SENTRY_REPORT report = (PRING_SENTRY_REPORT)buffer;
            RtlZeroMemory(report, sizeof(RING_SENTRY_REPORT));

            LARGE_INTEGER sysTime;
            KeQuerySystemTime(&sysTime);
            report->Timestamp = sysTime.QuadPart;

            // Audit execution rings 0 to -3 in descending order of abstract privilege
            AuditRing0Kernel(&report->Ring0);
            AuditRingMinus1Hypervisor(&report->RingMinus1);
            AuditRingMinus2Smm(&report->RingMinus2);
            AuditRingMinus3Platform(&report->RingMinus3);

            // Synthesize tamper determination
            BOOLEAN tampered = FALSE;
            if (report->Ring0.SsdtHookDetected ||
                report->Ring0.IdtHookDetected ||
                report->Ring0.HardwareBreakpointPresent ||
                report->RingMinus1.HypervisorTimingAnomalyDetected ||
                !report->RingMinus2.SmramLocked ||
                report->RingMinus2.SmramOpen ||
                report->RingMinus2.SmiAnomalyDetected ||
                report->RingMinus3.MeManufacturingModeActive ||
                !report->RingMinus3.MeStateClean) {
                tampered = TRUE;
            }

            report->OverallTamperDetected = tampered;
            bytesReturned = sizeof(RING_SENTRY_REPORT);
            status = STATUS_SUCCESS;
            break;
        }

        case IOCTL_RING_SENTRY_AUDIT_RING0: {
            if (outLen < sizeof(RING0_DIAGNOSTICS) || !buffer) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            status = AuditRing0Kernel((PRING0_DIAGNOSTICS)buffer);
            bytesReturned = sizeof(RING0_DIAGNOSTICS);
            break;
        }

        case IOCTL_RING_SENTRY_AUDIT_RING_MINUS1: {
            if (outLen < sizeof(RING_MINUS1_DIAGNOSTICS) || !buffer) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            status = AuditRingMinus1Hypervisor((PRING_MINUS1_DIAGNOSTICS)buffer);
            bytesReturned = sizeof(RING_MINUS1_DIAGNOSTICS);
            break;
        }

        case IOCTL_RING_SENTRY_AUDIT_RING_MINUS2: {
            if (outLen < sizeof(RING_MINUS2_DIAGNOSTICS) || !buffer) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            status = AuditRingMinus2Smm((PRING_MINUS2_DIAGNOSTICS)buffer);
            bytesReturned = sizeof(RING_MINUS2_DIAGNOSTICS);
            break;
        }

        case IOCTL_RING_SENTRY_AUDIT_RING_MINUS3: {
            if (outLen < sizeof(RING_MINUS3_DIAGNOSTICS) || !buffer) {
                status = STATUS_BUFFER_TOO_SMALL;
                break;
            }
            status = AuditRingMinus3Platform((PRING_MINUS3_DIAGNOSTICS)buffer);
            bytesReturned = sizeof(RING_MINUS3_DIAGNOSTICS);
            break;
        }

        default:
            status = STATUS_INVALID_DEVICE_REQUEST;
            break;
    }

    Irp->IoStatus.Status = status;
    Irp->IoStatus.Information = bytesReturned;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return status;
}

