#include <ntifs.h>
#include <ntddk.h>
#include <intrin.h>
#include "../include/ring_sentry.h"

#define IA32_LSTAR_MSR 0xC0000082

// Minimal representation for IDT descriptor
#pragma pack(push, 1)
typedef struct _IDTR {
    USHORT Limit;
    ULONG64 Base;
} IDTR, *PIDTR;

typedef struct _IDT_ENTRY64 {
    USHORT OffsetLow;
    USHORT Selector;
    USHORT IstIndex : 3;
    USHORT Reserved0 : 5;
    USHORT Type : 5;
    USHORT Dpl : 2;
    USHORT Present : 1;
    USHORT OffsetMiddle;
    ULONG  OffsetHigh;
    ULONG  Reserved1;
} IDT_ENTRY64, *PIDT_ENTRY64;
#pragma pack(pop)

// Forward declarations of undocumented structures when compiled against standard WDK
extern POBJECT_TYPE* IoDriverObjectType;

NTSTATUS AuditRing0Kernel(PRING0_DIAGNOSTICS Diag) {
    if (!Diag) return STATUS_INVALID_PARAMETER;
    RtlZeroMemory(Diag, sizeof(RING0_DIAGNOSTICS));

    // 1. Audit IA32_LSTAR MSR (System Call Target Address)
    ULONG64 lstar = __readmsr(IA32_LSTAR_MSR);
    Diag->LstarTargetAddress = lstar;

    // Check if LSTAR is within valid kernel module bounds
    // Cheats running via simple MSR hooks redirect LSTAR to custom trampolines
    if (lstar == 0 || lstar < 0xFFFFF80000000000ULL) {
        Diag->SsdtHookDetected = TRUE;
    }

    // 2. Audit Interrupt Descriptor Table (IDT)
    IDTR idtr = { 0 };
    __sidt(&idtr);

    if (idtr.Base == 0 || idtr.Limit == 0) {
        Diag->IdtHookDetected = TRUE;
    } else {
        PIDT_ENTRY64 idtEntries = (PIDT_ENTRY64)idtr.Base;
        // Check common vectors: 0x01 (Debug), 0x03 (Breakpoint), 0x0E (Page Fault)
        for (ULONG i = 0; i < 32; i++) {
            if (idtEntries[i].Present) {
                ULONG64 handlerAddr = ((ULONG64)idtEntries[i].OffsetHigh << 32) |
                                      ((ULONG64)idtEntries[i].OffsetMiddle << 16) |
                                      (ULONG64)idtEntries[i].OffsetLow;
                if (handlerAddr < 0xFFFFF80000000000ULL) {
                    Diag->IdtHookDetected = TRUE;
                    break;
                }
            }
        }
    }

    // 3. Audit Hardware Debug Registers (DR0-DR3, DR7)
    // Hardware breakpoints hook game memory execution transparently
    ULONG64 dr0 = __readdr(0);
    ULONG64 dr1 = __readdr(1);
    ULONG64 dr2 = __readdr(2);
    ULONG64 dr3 = __readdr(3);
    ULONG64 dr7 = __readdr(7);

    // If local or global breakpoint enable bits are set in DR7
    if ((dr7 & 0xFF) != 0 || dr0 != 0 || dr1 != 0 || dr2 != 0 || dr3 != 0) {
        Diag->HardwareBreakpointPresent = TRUE;
    }

    // 4. Audit CR3 / Page Table Base
    ULONG64 cr3 = __readcr3();
    Diag->Cr3Actual = cr3;
    if (cr3 == 0) {
        Diag->UnbackedExecutableMemoryPresent = TRUE;
    }

    return STATUS_SUCCESS;
}

