#include <ntddk.h>
#include <intrin.h>
#include "../include/ring_sentry.h"

#define IA32_FEATURE_CONTROL_MSR 0x3A
#define IA32_VMX_BASIC_MSR       0x480

#define TIMING_SAMPLE_COUNT      1000
#define VM_EXIT_THRESHOLD_RATIO  500 // > 5x latency compared to baseline indicates VM exit

NTSTATUS AuditRingMinus1Hypervisor(PRING_MINUS1_DIAGNOSTICS Diag) {
    if (!Diag) return STATUS_INVALID_PARAMETER;
    RtlZeroMemory(Diag, sizeof(RING_MINUS1_DIAGNOSTICS));

    int cpuInfo[4] = { 0 };

    // 1. Standard CPUID Hypervisor Detection
    // Leaf 1, ECX bit 31 is the hypervisor presence bit defined by hypervisor specs
    __cpuid(cpuInfo, 1);
    if ((cpuInfo[2] & (1 << 31)) != 0) {
        Diag->HypervisorPresentCpuid = TRUE;

        // Query Hypervisor Signature Leaf (0x40000000)
        int hvInfo[4] = { 0 };
        __cpuid(hvInfo, 0x40000000);
        RtlCopyMemory(&Diag->HypervisorSignature[0], &hvInfo[1], 4); // EBX
        RtlCopyMemory(&Diag->HypervisorSignature[4], &hvInfo[2], 4); // ECX
        RtlCopyMemory(&Diag->HypervisorSignature[8], &hvInfo[3], 4); // EDX
        Diag->HypervisorSignature[12] = '\0';
    }

    // 2. Hardware CR4 VMXE and MSR Lock Inspection
    ULONG64 cr4 = __readcr4();
    if ((cr4 & (1ULL << 13)) != 0) {
        Diag->Cr4VmxeActive = TRUE;
    }

    // Read MSR_IA32_FEATURE_CONTROL (0x3A)
    // Bit 0: Lock bit, Bit 1: Enable VMX in SMX, Bit 2: Enable VMX outside SMX
    ULONG64 featureControl = __readmsr(IA32_FEATURE_CONTROL_MSR);
    if ((featureControl & 1) != 0) {
        Diag->VmxLockedInMsr = TRUE;
    }

    // 3. VM-Exit Micro-Architectural Timing Differential Analysis
    // CPUID unconditionally induces a VM-Exit in guest mode under VMX/SVM.
    // We compare CPUID latency against a non-exiting baseline instruction (e.g. repeated NOPs/ADDs).
    unsigned int aux = 0;
    ULONG64 baselineTotal = 0;
    ULONG64 cpuidExitTotal = 0;

    for (ULONG i = 0; i < TIMING_SAMPLE_COUNT; i++) {
        // Measure baseline arithmetic instructions (no VM exit)
        _mm_lfence();
        ULONG64 startBaseline = __rdtscp(&aux);
        _mm_lfence();

        // Workload: 10 non-serializing, non-exiting instructions
        volatile ULONG dummy = 0;
        dummy += 1; dummy += 2; dummy += 3; dummy += 4;
        dummy += 5; dummy += 6; dummy += 7; dummy += 8;

        _mm_lfence();
        ULONG64 endBaseline = __rdtscp(&aux);
        _mm_lfence();
        baselineTotal += (endBaseline - startBaseline);

        // Measure CPUID execution (unconditional VM exit under VMX)
        _mm_lfence();
        ULONG64 startCpuid = __rdtscp(&aux);
        _mm_lfence();

        __cpuid(cpuInfo, 0);

        _mm_lfence();
        ULONG64 endCpuid = __rdtscp(&aux);
        _mm_lfence();
        cpuidExitTotal += (endCpuid - startCpuid);
    }

    ULONG64 avgBaseline = baselineTotal / TIMING_SAMPLE_COUNT;
    ULONG64 avgCpuid = cpuidExitTotal / TIMING_SAMPLE_COUNT;

    Diag->BaselineInstructionCycles = avgBaseline;
    Diag->AverageCpuidExitCycles = avgCpuid;

    if (avgBaseline > 0) {
        Diag->TimingRatio = (avgCpuid * 100) / avgBaseline;
    }

    // On bare-metal, CPUID leaf 0 typically completes within 100-250 cycles.
    // Under hypervisors with VM-Exit dispatch and emulation, it consistently exceeds 1000-2500+ cycles.
    if (avgCpuid > 1200 || Diag->TimingRatio > VM_EXIT_THRESHOLD_RATIO) {
        Diag->HypervisorTimingAnomalyDetected = TRUE;
    }

    // 4. Extended Page Table (EPT) Shadowing / Split-Page Detection
    // When a hypervisor splits a 2MB page into 4KB pages to place invisible read/write hooks,
    // memory access across page boundaries experiences TLB miss penalties and cache reloading differentials.
    volatile char probeBuffer[8192] = { 0 };
    _mm_clflush((void*)&probeBuffer[0]);
    _mm_clflush((void*)&probeBuffer[4096]);
    _mm_lfence();

    ULONG64 t0 = __rdtscp(&aux);
    volatile char c1 = probeBuffer[0];
    ULONG64 t1 = __rdtscp(&aux);

    volatile char c2 = probeBuffer[4096];
    ULONG64 t2 = __rdtscp(&aux);

    ULONG64 delta1 = t1 - t0;
    ULONG64 delta2 = t2 - t1;

    // Disproportionate jitter across adjacent physical pages under cold cache indicates EPT interception
    if ((delta1 > delta2 * 4) || (delta2 > delta1 * 4)) {
        Diag->EptShadowingDetected = TRUE;
    }

    return STATUS_SUCCESS;
}

