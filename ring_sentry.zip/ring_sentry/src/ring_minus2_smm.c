#include <ntddk.h>
#include <intrin.h>
#include "../include/ring_sentry.h"

#define IA32_SMI_COUNT_MSR       0x00000034

// PCI Configuration Ports
#define PCI_CONFIG_ADDRESS_PORT  0x0CF8
#define PCI_CONFIG_DATA_PORT     0x0CFC

// Intel Host Bridge (B0:D0:F0) Register Offsets
#define INTEL_HOST_BRIDGE_BUS    0
#define INTEL_HOST_BRIDGE_DEV    0
#define INTEL_HOST_BRIDGE_FUNC   0
#define REG_SMRAMC               0x88 // System Management RAM Control Register
#define REG_TSEGMB               0xB8 // TSEG Memory Base Register

// SMRAMC Bit Definitions
#define SMRAMC_D_LCK             (1 << 4) // SMRAM Lock Bit (1 = locked)
#define SMRAMC_D_OPEN            (1 << 6) // SMRAM Open Bit (1 = CPU code can access SMRAM)
#define SMRAMC_D_CLS             (1 << 5) // SMRAM Closed Bit

static ULONG PciReadConfigDword(ULONG Bus, ULONG Dev, ULONG Func, ULONG RegOffset) {
    ULONG address = (1U << 31) | (Bus << 16) | (Dev << 11) | (Func << 8) | (RegOffset & 0xFC);
    __outdword(PCI_CONFIG_ADDRESS_PORT, address);
    return __indword(PCI_CONFIG_DATA_PORT);
}

static UCHAR PciReadConfigByte(ULONG Bus, ULONG Dev, ULONG Func, ULONG RegOffset) {
    ULONG address = (1U << 31) | (Bus << 16) | (Dev << 11) | (Func << 8) | (RegOffset & 0xFC);
    __outdword(PCI_CONFIG_ADDRESS_PORT, address);
    return __inbyte(PCI_CONFIG_DATA_PORT + (RegOffset & 3));
}

NTSTATUS AuditRingMinus2Smm(PRING_MINUS2_DIAGNOSTICS Diag) {
    if (!Diag) return STATUS_INVALID_PARAMETER;
    RtlZeroMemory(Diag, sizeof(RING_MINUS2_DIAGNOSTICS));

    // 1. Audit SMRAM Controller (SMRAMC) on Host Bridge PCI Config Space
    UCHAR smramc = PciReadConfigByte(INTEL_HOST_BRIDGE_BUS, INTEL_HOST_BRIDGE_DEV, INTEL_HOST_BRIDGE_FUNC, REG_SMRAMC);

    // Verify D_LCK (Lock Bit): Must be 1 on secure hardware. If 0, SMRAM can be rewritten at runtime.
    if ((smramc & SMRAMC_D_LCK) != 0) {
        Diag->SmramLocked = TRUE;
    } else {
        Diag->SmramLocked = FALSE; // VULNERABILITY / ANOMALY: SMRAM unlocked
    }

    // Verify D_OPEN (Open Bit): Must be 0. If 1, non-SMM software can freely read/write SMRAM.
    if ((smramc & SMRAMC_D_OPEN) != 0) {
        Diag->SmramOpen = TRUE; // CRITICAL INTEGRITY FAILURE: SMRAM accessible from Ring 0
    }

    // 2. Read TSEG (Top of Low Usable DRAM) Base Register
    ULONG tsegmb = PciReadConfigDword(INTEL_HOST_BRIDGE_BUS, INTEL_HOST_BRIDGE_DEV, INTEL_HOST_BRIDGE_FUNC, REG_TSEGMB);
    Diag->TsegBaseAddress = (ULONG64)(tsegmb & 0xFFF00000); // 1MB aligned base
    Diag->TsegLimitAddress = Diag->TsegBaseAddress + (8ULL * 1024 * 1024); // Nominal TSEG window

    // 3. Monitor IA32_SMI_COUNT MSR (0x34)
    // SMM cheats hooking timers or device interrupts cause rapid SMI increments
    ULONG64 smiCountStart = __readmsr(IA32_SMI_COUNT_MSR);
    Diag->SmiCountInitial = smiCountStart;

    // High-resolution spin loop to detect SMI execution latency (Rendezvous jitter)
    unsigned int aux = 0;
    ULONG64 maxJitter = 0;

    for (ULONG i = 0; i < 500; i++) {
        _mm_lfence();
        ULONG64 tStart = __rdtscp(&aux);
        _mm_lfence();

        // 100 iterations of tight math operations
        volatile ULONG sum = 0;
        for (int j = 0; j < 100; j++) {
            sum += j;
        }

        _mm_lfence();
        ULONG64 tEnd = __rdtscp(&aux);
        _mm_lfence();

        ULONG64 delta = tEnd - tStart;
        if (delta > maxJitter) {
            maxJitter = delta;
        }
    }

    ULONG64 smiCountEnd = __readmsr(IA32_SMI_COUNT_MSR);
    Diag->SmiCountFinal = smiCountEnd;
    Diag->SmiDelta = smiCountEnd - smiCountStart;
    Diag->SmiExecutionJitterCycles = maxJitter;

    // If an SMI occurred during the tight loop or jitter exceeded normal interrupt threshold (>50,000 cycles)
    if (Diag->SmiDelta > 5 || maxJitter > 100000) {
        Diag->SmiAnomalyDetected = TRUE;
    }

    return STATUS_SUCCESS;
}

